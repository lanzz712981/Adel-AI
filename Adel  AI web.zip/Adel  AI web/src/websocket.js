const socket = new WebSocket('ws://your-websocket-url');

socket.onopen = () => {
    console.log('WebSocket connected');
};

socket.onmessage = (event) => {
    const message = event.data;
    displayMessage(message);
};

function displayMessage(message) {
    const chatBox = document.getElementById('chat-box');
    chatBox.innerHTML += '<div class="bot-message">${message}</div>';
}