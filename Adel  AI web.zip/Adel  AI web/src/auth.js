document.getElementById('login-form').addEventListener('submit', function (event) {
    event.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    authenticateUser(username, password).then(response => {
        if (response.success) {
            window.location.href = '/profile.html';
        } else {
            alert('Login failed. Please check your credentials.');
        }
    });
});