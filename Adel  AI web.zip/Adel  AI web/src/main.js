document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('message-form');
    const input = document.getElementById('message-input');
    const chatBox = document.getElementById('chat-box');

    form.addEventListener('submit', (event) => {
        event.preventDefault();

        const message = input.value;
        if (message) {
            sendMessage(message);
            input.value = '';
        }
    });

    function sendMessage(message) {
        chatBox.innerHTML += '<div class="user-message">${message}</div>';
    }
});