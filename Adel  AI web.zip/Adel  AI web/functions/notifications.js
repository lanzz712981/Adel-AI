function sendNotification(message) {
    const notification = new Notification("New Message", {
        body: message,
        icon: "assets/images/logo.png"
    });
}