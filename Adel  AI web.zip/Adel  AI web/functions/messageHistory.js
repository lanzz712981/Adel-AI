let messageHistory = [];

function saveMessage(message) {
    messageHistory.push(message);
}

function getHistory() {
    return messageHistory;
}