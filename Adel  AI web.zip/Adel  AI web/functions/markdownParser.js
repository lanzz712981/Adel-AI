function parseMarkdown(text) {
    // Simple markdown parser
    return text.replace(/(.*?)/g, '<em>$1</em>');
}