# AdelAI - AI Chat Web App

This is a professional AI chat web application powered by AdelAI.

## Features:
- Real-time chat
- User authentication (Login/Register)
- AI responses powered by AdelAI API
- Profile page and settings

## How to Run:
1. Clone the repository
2. Install dependencies: npm install
3. Start the server: npm start
4. Visit http://localhost:3000 in your browser.

## Deployment:
Deploy on Vercel by connecting your GitHub repository or by manually uploading.

## License:
MIT License