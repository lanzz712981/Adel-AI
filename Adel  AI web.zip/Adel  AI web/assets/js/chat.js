document.getElementById("message-form").addEventListener("submit", function (e) {
    e.preventDefault();
    const message = document.getElementById("message-input").value;
    addMessageToChat(message, "user");
    getAIResponse(message).then(response => {
        addMessageToChat(response, "bot");
    });
});

function addMessageToChat(message, sender) {
    const chatBox = document.getElementById("chat-box");
    const messageDiv = document.createElement("div");
    messageDiv.classList.add("message", sender);
    messageDiv.textContent = message;
    chatBox.appendChild(messageDiv);
}