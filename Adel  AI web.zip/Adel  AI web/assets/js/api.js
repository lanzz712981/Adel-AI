const apiUrl = 'https://api.siputzx.my.id/api/ai/deepseek-llm-67b-chat';

async function getAIResponse(message) {
    const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ message: message })
    });

    const data = await response.json();
    return data.reply;
}