const socket = io();

socket.on("chat message", function (msg) {
    addMessageToChat(msg, "bot");
});

function sendMessageToServer(message) {
    socket.emit("chat message", message);
}