let chatHistory = [];

function saveMessageToHistory(message) {
    chatHistory.push(message);
}

function loadChatHistory() {
    return chatHistory;
}