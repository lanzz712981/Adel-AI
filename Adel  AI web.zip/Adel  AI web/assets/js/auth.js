function authenticateUser(username, password) {
    // Logic for authentication
    return fetch('/login', {
        method: 'POST',
        body: JSON.stringify({ username, password }),
        headers: { 'Content-Type': 'application/json' }
    });
}