// Logic for interactions, e.g., user click actions
document.getElementById("open-sidebar").addEventListener("click", function () {
    toggleSidebar();
});